document.querySelectorAll('#main-genres text').forEach(e=>e.addEventListener('click',()=>parent.postMessage({kind:'work',id:Number(e.dataset.code.slice(1))},location.origin)));
 document.addEventListener('click',function(e){if(e.target.closest('#zoom-in,#zoom-out')&&getComputedStyle(document.querySelector('#loading-animation')).display!=='none'){e.stopImmediatePropagation();e.preventDefault();}},true);

// Keep the original zoom handlers; only replace the stretched text glyphs.
for (const id of ['zoom-in','zoom-out']) {
  const button=document.getElementById(id);
  button.innerHTML='<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M5 12h14'+(id==='zoom-in'?'M12 5v14':'')+'" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
}

const svgNS='http://www.w3.org/2000/svg';
const viewport=document.getElementById('viewport');
const guide=document.createElementNS(svgNS,'g');
guide.id='work-year-guide';guide.setAttribute('aria-hidden','true');
document.getElementById('genres').parentNode.insertBefore(guide,document.getElementById('genres')); 
// Years and works share the viewport coordinate system. Derive both endpoints
// from live SVG text bounds, including the text's own transform.
const works=[...document.querySelectorAll('#main-genres > text')];
const years=[...document.querySelectorAll('#decades-text > text[data-year]')];
const genres=document.getElementById('genres');
const mapSvg=document.getElementById('musicmap');
// Wheel zoom is handled by the original Musicmap controller inside the map.
const workYear=label=>label.querySelector('title')?.textContent.match(/·\s*(\d{4})\s*·/)?.[1];
function anchor(element,edge){
  const box=element.getBBox();
  const local=new DOMPoint(box.x+(edge==='left'?0:edge==='right'?box.width:box.width/2),box.y+box.height/2);
  return local.matrixTransform(element.getCTM()).matrixTransform(guide.parentNode.getCTM().inverse());
}
function hideYearGuide(){
  guide.classList.remove('is-visible');guide.replaceChildren();mapSvg.classList.remove('has-relation-focus');
  mapSvg.classList.remove('is-year-peek');genres.classList.remove('is-year-peek');
  document.querySelectorAll('.is-active-year,.is-year-work').forEach(e=>e.classList.remove('is-active-year','is-year-work'));
}
function connect(yearNode,work){
  const yearIsLeft=anchor(yearNode,'center').x<anchor(work,'center').x;
  const from=anchor(yearNode,yearIsLeft?'right':'left');
  const to=anchor(work,yearIsLeft?'left':'right');
  const gap=6;
  from.x+=yearIsLeft?gap:-gap;to.x+=yearIsLeft?-gap:gap;
  const path=document.createElementNS(svgNS,'path');
  path.dataset.year=yearNode.dataset.year;path.dataset.work=work.dataset.code;
  path.setAttribute('d',`M${from.x} ${from.y}L${to.x} ${to.y}`);
  guide.appendChild(path);
}
function showWork(label){
  hideYearGuide();const year=workYear(label);if(!year)return;
  years.filter(node=>node.dataset.year===year).forEach(node=>{
    node.classList.add('is-active-year');connect(node,label);
  });
  label.classList.add('is-year-work');mapSvg.classList.add('has-relation-focus');guide.classList.add('is-visible');
}
function showYear(node){
  hideYearGuide();const matches=works.filter(label=>workYear(label)===node.dataset.year);
  if(!matches.length)return;
  if(Number(getComputedStyle(genres).opacity)<.1){
    mapSvg.classList.add('is-year-peek');genres.classList.add('is-year-peek');
  }
  years.filter(y=>y.dataset.year===node.dataset.year).forEach(y=>y.classList.add('is-active-year'));
  matches.forEach(work=>{work.classList.add('is-year-work');connect(node,work)});
  mapSvg.classList.add('has-relation-focus');guide.classList.add('is-visible');
}
works.forEach(label=>{
  label.addEventListener('pointerenter',()=>showWork(label));
  label.addEventListener('pointerleave',hideYearGuide);
  label.setAttribute('tabindex','0');
  label.addEventListener('focus',()=>showWork(label));label.addEventListener('blur',hideYearGuide);
});
years.forEach(node=>{
  node.setAttribute('tabindex','0');node.setAttribute('role','button');
  node.setAttribute('aria-label',`${node.dataset.year} 年的作品`);
  node.addEventListener('pointerenter',()=>showYear(node));node.addEventListener('pointerleave',hideYearGuide);
  node.addEventListener('focus',()=>showYear(node));node.addEventListener('blur',hideYearGuide);
});
new MutationObserver(()=>{hideYearGuide();mapSvg.classList.toggle('is-detail-view',Number(genres.style.opacity)>.01)}).observe(genres,{attributes:true,attributeFilter:['style']});
