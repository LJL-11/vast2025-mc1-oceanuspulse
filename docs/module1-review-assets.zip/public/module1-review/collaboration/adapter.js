showPopup=function(d){};showDialogPopup=function(){};
(function(){
  var root=document.getElementById('network'),selected=null,ready=false;
  var controls=document.createElement('div');controls.className='collab-controls';
  controls.innerHTML='<button type="button" data-action="out" aria-label="缩小合作图">−</button><button type="button" data-action="in" aria-label="放大合作图">+</button><button type="button" data-action="fit">显示全部</button>';
  document.body.appendChild(controls);
  function apply(s,t,animate){
    scale=s;trans=t;zoom.translate(t).scale(s);
    var target=animate?vis.transition().duration(650).ease('cubic-in-out'):vis;
    target.attr('transform','translate('+t+') scale('+s+')');
  }
  function fit(animate){
    if(!vis||!root.querySelector('.node'))return;
    var nodes=root.querySelectorAll('.node'),left=Infinity,top=Infinity,right=-Infinity,bottom=-Infinity;
    for(var i=0;i<nodes.length;i++){
      var d=nodes[i].__data__,b=nodes[i].getBBox();
      left=Math.min(left,d.x+b.x);right=Math.max(right,d.x+b.x+b.width);
      top=Math.min(top,d.y+b.y);bottom=Math.max(bottom,d.y+b.y+b.height);
    }
    var w=root.clientWidth,h=root.clientHeight;
    var insetX=24, insetTop=24, insetBottom=62;
    var s=Math.min(1.65,(w-insetX*2)/(right-left),(h-insetTop-insetBottom)/(bottom-top));
    if(s<=0)return;
    apply(s,[(w-(right+left)*s)/2,(h+insetTop-insetBottom-(bottom+top)*s)/2],animate);
  }
  function separate(steps){
    var els=[].slice.call(root.querySelectorAll('.node'));
    els.forEach(function(el){
      var text=el.querySelector('text'),label=el.__data__.label;
      if(label.length>17){
        var words=label.split(' '),cut=Math.ceil(words.length/2),a=words.slice(0,cut).join(' '),b=words.slice(cut).join(' ');
        if(b){text.textContent='';[a,b].forEach(function(line,i){var t=document.createElementNS('http://www.w3.org/2000/svg','tspan');t.setAttribute('x','0');t.setAttribute('dy',i?'16':'0');t.textContent=line;text.appendChild(t)})}
      }
    });
    var boxes=els.map(function(el){return el.getBBox()});
    for(var step=0;step<(steps||1);step++){
      for(var i=0;i<els.length;i++)for(var j=i+1;j<els.length;j++){
        var a=els[i].__data__,b=els[j].__data__,ra=boxes[i],rb=boxes[j];
        var dx=(a.x+ra.x+ra.width/2)-(b.x+rb.x+rb.width/2);
        var dy=(a.y+ra.y+ra.height/2)-(b.y+rb.y+rb.height/2);
        var ox=(ra.width+rb.width)/2+12-Math.abs(dx),oy=(ra.height+rb.height)/2+12-Math.abs(dy);
        if(ox<=0||oy<=0)continue;
        var ax=a.id===usePerson?0:b.id===usePerson?1:.5,bx=1-ax;
        if(ox<oy){var move=(ox+.5)*(dx<0?-1:1);a.x+=move*ax;b.x-=move*bx}
        else{var move=(oy+.5)*(dy<0?-1:1);a.y+=move*ax;b.y-=move*bx}
      }
    }
    els.forEach(function(el){var d=el.__data__;el.setAttribute('transform','translate('+d.x+','+d.y+')')});
    vis.selectAll('line.link').attr('x1',function(d){return pointsBetween(d.source,d.target)[0][0]}).attr('y1',function(d){return pointsBetween(d.source,d.target)[0][1]}).attr('x2',function(d){return pointsBetween(d.source,d.target)[1][0]}).attr('y2',function(d){return pointsBetween(d.source,d.target)[1][1]});
  }
  function focus(id,notify){
    selected=id;
    root.querySelectorAll('.node').forEach(function(el){
      el.classList.toggle('is-selected',Number(el.__data__.id.split('/n').pop())===id);
    });
    if(notify)parent.postMessage({kind:'collaborator',id:id},location.origin);
  }
  root.addEventListener('click',function(e){
    var node=e.target.closest('g.node');if(!node)return;
    focus(Number(node.__data__.id.split('/n').pop()),true);
  });
  controls.addEventListener('click',function(e){
    var action=e.target.dataset.action;if(!action||!ready)return;
    if(action==='fit'){fit(true);return;}
    var w=root.clientWidth/2,h=root.clientHeight/2;
    var next=Math.max(.25,Math.min(6,scale*(action==='in'?1.25:.8))),ratio=next/scale;
    apply(next,[w-(w-trans[0])*ratio,h-(h-trans[1])*ratio],true);
  });
  window.addEventListener('message',function(e){
    if(e.origin!==location.origin||e.data?.kind!=='select-collaborator')return;
    focus(Number(e.data.id),false);
  });
  var lastPerson=null;
  var timer=setInterval(function(){
    if(usePerson!==lastPerson){ready=false;lastPerson=usePerson;}
    if(ready||!force||!vis||rendering||!root.querySelector('.node')||force.alpha()>.025)return;
    separate(12);ready=true;fit(true);
    parent.postMessage({kind:'collab-ready'},location.origin);
    force.on('tick.review',function(){separate(1)});
    root.querySelectorAll('.node').forEach(function(el){
      el.setAttribute('tabindex','0');el.setAttribute('role','button');el.setAttribute('aria-label',el.__data__.label);
      el.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();focus(Number(el.__data__.id.split('/n').pop()),true)}});
    });
  },100);
  var resizeTimer;
  new ResizeObserver(function(){clearTimeout(resizeTimer);resizeTimer=setTimeout(function(){
    if(!ready)return;
    root.querySelector('svg').setAttribute('width',root.clientWidth);
    root.querySelector('svg').setAttribute('height',root.clientHeight);
    fit();
  },100)}).observe(root);
})();
