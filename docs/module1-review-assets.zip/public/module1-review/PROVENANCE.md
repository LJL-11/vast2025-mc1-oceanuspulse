# Local review only
Musicmap: original locally held HTML/CSS/bundle retained; new work data, labels, evidence and embedding styles. Copyright Kwinten & Dries Crauwels; no open-source license confirmed.
LOTR: https://github.com/nbremer/lotr (gh-pages), original loom.js, string.js and script.js hover transitions retained. Data adapter, labels and wrapper changed. No explicit license confirmed.
Linked Jazz: https://github.com/thisismattmiller/linked-jazz-network, MIT in upstream README retained. Original network renderer, layout, zoom and force interaction retained. Local RDF adapter, initials and evidence bridge added; no real portraits invented.
These are local review assets; redistribution is pending rights review for Musicmap and LOTR.
